#ifndef _ThreePointGain
#define _ThreePointGain

#include "main.h"

// STL
#include <iostream>
#include <string.h>
#include <map>
#include <stdlib.h>
#include <dirent.h>
#include <iomanip>
#include <vector>
// ROOT
#include "TChain.h"
#include "TF1.h"
#include "TH1.h"
#include "TH2.h"
#include "TTree.h"
#include "TGraph.h"
#include "TGraphErrors.h"
#include "TMultiGraph.h"
#include "TCanvas.h"
#include "TGaxis.h"
#include "TLatex.h"

class ThreePointGain{

 private:
  TH1F* hgain;
  TH1F* hnoise;
  TH1F* hoffset;
  TGraphErrors* gthree[nside][nstrip];
  TF1* func[nside][nstrip];
  Double_t thr_dac[nside][nstrip];

  bool finitialize;

 public:
  ThreePointGain();
  ~ThreePointGain();
  void Initialize();
  void FillEvents(TChain* chain, TH1F* hhit[nside], TH1F* hthr[nside][nstrip]);
  void PlotSummary(std::string srun[nrun_gain]);
  void PlotStripGain(std::string srun[nrun_gain]);
  void MakePlots(int runid[nrun_gain]);
  void CheckNoisyStrips(int runid);
};

#endif

