#include "ThreePointGain.h"
#include "ThrScan.h"
#include "NoiseScan.h"
#include <fstream>
#include <sstream>
#include <time.h>
#include <map>
#include <stdio.h>
#include "TChain.h"
#include "TROOT.h"
#include "TFile.h"
#include "TStyle.h"
#include "TProfile.h"
#include "TKey.h"
#include "Riostream.h"
#include "TEventList.h"
#include "TDirectory.h"
#include "TObject.h"
#include "TLegend.h"
#include "TMath.h" 
#include "TEllipse.h" 

ThreePointGain::ThreePointGain(){
  finitialize = false;

  for(int i=0; i<nside; i++){
    for(int j=0; j<nstrip; j++){
      thr_dac[i][j] = 0;
    }
  }
}

ThreePointGain::~ThreePointGain(){
  if(finitialize){
    delete hnoise;
    delete hgain;
    delete hoffset;
    for(int i=0; i<nside; i++){
      for(int j=0; j<nstrip; j++){
	delete gthree[i][j];
	delete func[i][j];
      }
    }
  }
}

void ThreePointGain::Initialize(){
  finitialize = true;

  hnoise = new TH1F("hnoise", "", 100, 0., 3500.);
  hnoise->SetXTitle("ENC[e]");
  hnoise->SetYTitle("Strips");

  hgain = new TH1F("hgain", "Gain (Typical gain: 50mV/fC)", 100, 0., 100.);
  hgain->SetXTitle("Gain[mV/fC]");
  hgain->SetYTitle("Strips");

  hoffset = new TH1F("hoffset", "Offset", 100, 0., 200.);
  hoffset->SetXTitle("Offset[mV]");
  hoffset->SetYTitle("Strips");

  for(int i=0; i<nside; i++){
    for(int j=0; j<nstrip; j++){
      std::ostringstream ofunc;
      ofunc << "func_" << i << "_" << j;
      func[i][j] = new TF1((ofunc.str()).c_str(),"[0]+[1]*x", 0., 4.);
      func[i][j]->SetLineColor(kRed);
      //func[i][j]->SetLineWidth(1);
    }
  }      
}

void ThreePointGain::PlotSummary(std::string srun[]){
  TCanvas *c1 = new TCanvas("c1", "small cluster energy", 0, 0, 800, 800);

  gStyle->SetOptStat(1110);
  gStyle->SetStatX(0.9);
  gStyle->SetStatY(0.9);
  gStyle->SetStatW(0.3);
  hgain->SetStats(1);
  hoffset->SetStats(1);
  hnoise->SetStats(1);

  hgain->SetMaximum(hgain->GetMaximum() * 1.2);
  hoffset->SetMaximum(hoffset->GetMaximum() * 1.2);
  hnoise->SetMaximum(hnoise->GetMaximum() * 1.2);

  c1->Divide(2,2);
  c1->cd(1); hgain->Draw();
  c1->cd(2); hoffset->Draw();
  c1->cd(3); hnoise->Draw();

  std::string spng = "run";
  for(int i=0; i<nrun_gain; i++){
    spng += "_";
    spng += srun[i];
  }
  spng += "_ThreePointGainSummary.png";
  c1->Print(spng.c_str());

  std::cout << std::endl;
  std::cout << "=== Gain & Noise =============" << std::endl;
  std::cout << "* Gain : " << hgain->GetMean() << " +- " << hgain->GetRMS() << " mV/fC" << std::endl;
  std::cout << "* Noise: " << hnoise->GetMean() << " +- " << hnoise->GetRMS() << " electrons" << std::endl;
  std::cout << "==============================" << std::endl;
  std::cout << std::endl;


  delete c1;
}

void ThreePointGain::PlotStripGain(std::string srun[nrun_gain]){
  std::string spdf = "run";
  for(int i=0; i<nrun_gain; i++){
    spdf += "_";
    spdf += srun[i];
  }
  std::string spdf0 = spdf;
  std::string spdf1 = spdf;
  std::string spdf2 = spdf;
  spdf0 += "_ThreePointGainAll.pdf[";
  spdf1 += "_ThreePointGainAll.pdf";
  spdf2 += "_ThreePointGainAll.pdf]";

  TCanvas *c2 = new TCanvas("c2", "small cluster energy", 0, 0, 800, 800);
  c2->Divide(8,8);
  int nn = 0;
  c2->Print(spdf0.c_str());
  for(int i=0; i<nside; i++){
    for(int j=0; j<nstrip; j++){
      //for(int i=1; i<2; i++){
      //for(int j=0; j<128; j++){
      std::ostringstream ohthr;
      ohthr << "gain_" << i << "_" << j;
      gthree[i][j]->SetTitle((ohthr.str()).c_str());
      if(nn != 0 && nn%64 == 0){
	c2->Update();
	c2->Print(spdf1.c_str());
	c2->Clear();
	c2->Divide(8,8);
      }
      c2->cd(nn%64 + 1);
      gthree[i][j]->SetMarkerStyle(20);
      gthree[i][j]->SetMarkerSize(0.5);
      gthree[i][j]->Draw("apw");
      func[i][j]->Draw("same");
      nn++;
    }
  }
  c2->Print(spdf1.c_str());
  c2->Print(spdf2.c_str());

  delete c2;
}

void ThreePointGain::MakePlots(int runid[nrun_gain]){

  gStyle->SetOptStat(0);
  gStyle->SetOptFit(0);
  gStyle->SetPalette(1);


  Double_t charge[nrun_gain] = {1.5, 2.0, 2.5}; //fC
  Double_t chargee[nrun_gain] = {0., 0., 0.}; //fC
  Double_t vt50[nside][nstrip][nrun_gain];
  Double_t vt50e[nside][nstrip][nrun_gain];
  Double_t sigma[nside][nstrip][nrun_gain];
  std::string srun[nrun_gain];
  for(int a=0; a<nrun_gain; a++){
    std::cout << "Analysing run" << runid[a] << std::endl;

    std::ostringstream orun;
    orun << runid[a];
    srun[a] = orun.str();

    ThrScan* m_ThrScan = new ThrScan();
    m_ThrScan->Analyze(runid[a]);

    Double_t parth[nside][nstrip][4];
    m_ThrScan->FitScurve(parth);

    for(int i=0; i<nside; i++){
      for(int j=0; j<nstrip; j++){  
	vt50[i][j][a] = parth[i][j][0];
	vt50e[i][j][a] = parth[i][j][2];
	sigma[i][j][a] = parth[i][j][1];
      }
    }

    if(a == 1) m_ThrScan->PlotBadStrips(srun[a]);
    delete m_ThrScan;
  }//for(int a=0; a<nrun_gain; a++)
  
  
  Initialize();
  for(int i=0; i<nside; i++){
    for(int j=0; j<nstrip; j++){  
      gthree[i][j] = new TGraphErrors(nrun_gain, charge, vt50[i][j], chargee, vt50e[i][j]);

      std::ostringstream ofunc;
      ofunc << "func_" << i << "_" << j;
      gthree[i][j]->Fit((ofunc.str()).c_str(), "NQ");

      Double_t par[2];
      func[i][j]->GetParameters(&par[0]);
      Double_t gain = 1./par[1]; // fC/mV

      hgain->Fill(par[1]);
      hoffset->Fill(par[0]);

      Double_t noise = sigma[i][j][1] * gain / 0.0001602; // electron
      hnoise->Fill(noise);

      thr_dac[i][j] = round((par[0] + par[1])/2.5);
    }
  }
  
  PlotSummary(srun);
  PlotStripGain(srun);
}

void ThreePointGain::CheckNoisyStrips(int runid){
    std::cout << "Analysing run" << runid << std::endl;

    NoiseScan* m_NoiseScan = new NoiseScan();
    m_NoiseScan->CheckNoisyStrips(runid, thr_dac);

    delete m_NoiseScan;
}
